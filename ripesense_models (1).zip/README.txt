Copy the models/ files into ~/ripesense/models/ on the Pi:
  fruit_classifier.onnx + fruit_classifier.onnx.labels.json  -> loaded automatically by the scanner
  public_gas_rows.csv  -> ripesense train --public models/public_gas_rows.csv  (after labelling scans)
  ethylene_curve.json, respiration_reference.csv  -> reference data
reports/ has accuracy per class and per source dataset.
